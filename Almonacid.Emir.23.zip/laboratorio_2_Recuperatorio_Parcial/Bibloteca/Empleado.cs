﻿namespace Bibloteca
{
    public abstract class Empleado
    {
        
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        
        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaIngreso = horaIngreso;
        }

        
        public string Nombre
        {
            get { return nombre; }
        }

        public string Legajo
        {
            get { return legajo; }
        }

        public TimeSpan HoraIngreso
        {
            get { return horaIngreso; }
        }

        
        public TimeSpan HoraEgreso
        {
            get { return horaEgreso; }
            set { horaEgreso = ValidaHoraEgreso(value); }
        }

        private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso)
        {
            if (horaEgreso > horaIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }

        public double Facturar()
        {
            return (horaEgreso - horaIngreso).TotalHours;
        }

        public static bool operator ==(Empleado empleado1, Empleado empleado2)
        {
            if (ReferenceEquals(empleado1, null) || ReferenceEquals(empleado2, null))
            {
                return ReferenceEquals(empleado1, empleado2);
            }
            return empleado1.legajo == empleado2.legajo;
        }

        public static bool operator !=(Empleado empleado1, Empleado empleado2)
        {
            return !(empleado1 == empleado2);
        }

        public string EmitirFactura()
        {
            return $"Empleado: {Nombre}, Total Horas Trabajadas: {Facturar()}";
        }
    }
}
