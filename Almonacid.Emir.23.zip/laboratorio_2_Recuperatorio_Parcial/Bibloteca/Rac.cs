﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibloteca
{
    using System;

    
    public class Rac : Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private static double valorHora = 875.90;
        private EGrupo grupo;

        private Rac()
            : base("DefaultLegajo", "DefaultNombre", TimeSpan.Zero)
        {
            this.grupo = EGrupo.CALL_IN;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso)
            : base(legajo, nombre, horaIngreso)
        {
            grupo = EGrupo.CALL_IN;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo)
            : base(legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        

        public EGrupo Grupo
        {
            get { return grupo; }
        }

        public static double ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        private double CalculaBono()
        {
            switch (grupo)
            {
                case EGrupo.CALL_OUT:
                    return 0.1;
                case EGrupo.RRSS:
                    return 0.2;
                default:
                    return 0.0;
            }
        }

        public string EmitirFactura()
        {
            return $"Factura de: {ToString()}\nImporte a facturar: {Facturar()}";
        }

        internal double Facturar()
        {
            double bono = CalculaBono();
            return (HoraEgreso - HoraIngreso).TotalHours * valorHora * (1 + bono);
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {grupo} - {Legajo} - {Nombre}";
        }
    }
}