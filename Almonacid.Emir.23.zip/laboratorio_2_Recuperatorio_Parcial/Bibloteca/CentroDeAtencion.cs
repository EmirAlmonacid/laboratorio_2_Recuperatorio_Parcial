﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibloteca
{
    public class CentroDeAtencion
    {
        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;
            this.cantRacsPorSuper = cantRacsPorSuper;
            this.empleados = new List<Empleado>();
        }

        public List<Empleado> Empleados
        {
            get { return empleados; }
        }

        public string Nombre
        {
            get { return nombre; }
        }

        private bool ValidaCantidadDeRacs()
        {
            int supervisores = empleados.Count(e => e is Supervisor);
            int racs = empleados.Count(e => e is Rac);
            return racs > supervisores * cantRacsPorSuper;
        }

        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            return c.empleados.Contains(e);
        }

        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !c.empleados.Contains(e);
        }

        public static bool operator +(CentroDeAtencion c, Empleado e)
        {
            if (c == e)
            {
                return false;
            }

            if (e is Supervisor && c.ValidaCantidadDeRacs())
            {
                return false;
            }

            c.empleados.Add(e);
            return true;
        }

        public static string operator -(CentroDeAtencion c, Empleado e)
        {
            if (c == e)
            {
                e.HoraEgreso = DateTime.Now.TimeOfDay;
                string factura = $"Empleado {e.Nombre} facturó {e.Facturar()} horas.";
                c.empleados.Remove(e);
                return factura;
            }
            return "Empleado no encontrado";
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var empleado in empleados)
            {
                sb.AppendLine($"{empleado.Nombre} ({empleado.Legajo})");
            }
            return sb.ToString();
        }
    }
}
