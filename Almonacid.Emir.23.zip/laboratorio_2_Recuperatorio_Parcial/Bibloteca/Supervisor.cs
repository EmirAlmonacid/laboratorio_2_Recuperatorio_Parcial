﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bibloteca
{
    public class Supervisor : Empleado
    {
        private static float valorHora = 1025.50F;

        public Supervisor()
           : base("DefaultLegajo", "DefaultNombre", TimeSpan.Zero)
        {
        }

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso)
            : base(legajo, nombre, horaIngreso)
        {
        }

        private Supervisor(string legajo)
            : base(legajo, "n/a", new TimeSpan(09, 00, 00))
        {
        }

        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public string EmitirFactura()
        {
            return $"Factura de: {ToString()}\nImporte a facturar: {Facturar()}";
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {legajo} - {nombre}";
        }

        public new double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours * valorHora;
        }

        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo);
        }
    }
}
